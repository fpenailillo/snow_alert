# F7: Escritura del Informe Final de Tesina

## Cuándo usar este flujo

Cuando el usuario pide escribir capítulos, secciones, o el informe final de la tesina. También cuando pide revisar redacción, generar figuras, tablas o referencias IEEE.

## Requisitos formales UTFSM (MTI-401)

- **Máximo 25 páginas** en cuerpo del documento (sin anexos ni referencias)
- Lenguaje formal, preciso, técnico
- Citas y referencias en **formato IEEE**
- Organización coherente en capítulos/secciones
- Examen de graduación: idealmente **antes de septiembre 2026**
- Comisión de Examen: 3 miembros
- Tutor: Dr. Mauricio Solar

## Estructura propuesta del informe final

```
Capítulo 1: Introducción (2-3 pp)
  1.1 Contexto y motivación
  1.2 Definición del problema
  1.3 Objetivos (general + específicos)
  1.4 Hipótesis de trabajo (H1-H4)
  1.5 Estructura del documento

Capítulo 2: Marco teórico y estado del arte (4-5 pp)
  2.1 Escala EAWS y predicción de avalanchas
  2.2 Sistemas multi-agente en IA
  2.3 Physics-Informed Neural Networks (PINNs)
  2.4 Vision Transformers para datos satelitales
  2.5 NLP para extracción de conocimiento experto
  2.6 Infraestructura serverless GCP
  2.7 Trabajos relacionados (Techel 2022, SLF, SNOWPACK)

Capítulo 3: Diseño e implementación (5-6 pp)
  3.1 Arquitectura general del sistema
  3.2 Pipeline de datos (6 Cloud Functions)
  3.3 Subagente topográfico (S1: PINNs + DEM SRTM)
  3.4 Subagente satelital (S2: ViT + MODIS/GEE)
  3.5 Subagente meteorológico (S3: Google Weather API)
  3.6 Subagente NLP (S4: relatos Andeshandbook)
  3.7 Subagente integrador (S5: clasificación EAWS)
  3.8 Decisiones de diseño relevantes

Capítulo 4: Validación y resultados (4-5 pp)
  4.1 Metodología de validación
  4.2 Resultados H1: F1-score macro
  4.3 Resultados H2: ablación NLP (+7.9pp)
  4.4 Resultados H3: benchmark Techel (2022)
  4.5 Resultados H4: concordancia Snowlab
  4.6 Análisis de confianza y cobertura
  4.7 Pruebas estadísticas (bootstrap, McNemar)

Capítulo 5: Marco ético-legal (1-2 pp)
  5.1 Regulación chilena (Ley 21.719)
  5.2 Responsabilidad y disclaimer
  5.3 Principio de precaución en IA de seguridad

Capítulo 6: Conclusiones y trabajo futuro (2-3 pp)
  6.1 Conclusiones por hipótesis
  6.2 Contribuciones principales
  6.3 Limitaciones
  6.4 Trabajo futuro

Referencias bibliográficas (formato IEEE)
Anexos (sin límite de páginas)
  A. Schema BigQuery completo
  B. Ejemplo de boletín generado
  C. Decisiones de diseño D1-D13
  D. Código fuente relevante
```

## Convenciones de escritura

### Tono y estilo
- Tercera persona o impersonal: "se implementó", "el sistema genera"
- Evitar primera persona excepto en conclusiones: "se concluye que..."
- Verbos en pasado para lo implementado, presente para lo que el sistema hace
- Precisión técnica: nombres completos la primera vez + acrónimo entre paréntesis

### Figuras y tablas
- Toda figura y tabla debe ser referenciada en el texto
- Numeración secuencial: Figura 1, Tabla 1
- Caption descriptivo debajo de figuras, encima de tablas
- Figuras generables con Mermaid, matplotlib, o diagrams

### Referencias IEEE
```
[1] A. Vaswani et al., "Attention is all you need," in Advances in Neural Information Processing Systems, vol. 30, 2017.
[2] F. Techel, C. Mitterer, E. Ceaglio, and J. Coléou, "Spatial consistency and bias in avalanche forecasts," Nat. Hazards Earth Syst. Sci., vol. 22, pp. 2521-2541, 2022.
[3] M. Raissi, P. Perdikaris, and G. E. Karniadakis, "Physics-informed neural networks," J. Comput. Phys., vol. 378, pp. 686-707, 2019.
```

## Mapeo código → secciones de la tesina

| Sección tesina | Archivos del código | Qué extraer |
|----------------|---------------------|-------------|
| §3.1 Arquitectura | `agente_principal.py`, `docs/arquitectura.md` | Diagrama, flujo S1→S5 |
| §3.3 PINN | `tool_calcular_pinn.py` | Ecuaciones, UQ, gradiente térmico |
| §3.4 ViT | `tool_analizar_vit.py` | MHA, PE sinusoidal, arquitectura |
| §3.5 Meteo | `tool_condiciones.py`, `tool_pronostico.py` | Ventanas críticas, tendencias |
| §3.6 NLP | `tool_conocimiento_historico.py`, `conocimiento_base_andino.py` | Fallback, 15 zonas, estacional |
| §3.7 EAWS | `tool_clasificar_eaws.py`, `eaws_constantes.py` | Matriz, tamaño dinámico, viento |
| §3.8 Decisiones | `docs/decisiones_diseno.md` | D1-D13 |
| §4.1 Metodología | `metricas_eaws.py` | F1-macro, Kappa, QWK |
| §4.2 H1 | `01_validacion_f1_score.py` | Matriz confusión, IC 95% |
| §4.3 H2 | `02_analisis_ablacion.py`, `06_analisis_nlp_sintetico.py` | Delta +7.9pp |
| §4.4 H3 | `metricas_eaws.py` → `comparar_con_techel_2022()` | QWK, accuracy ±1 |
| §4.5 H4 | `03_comparacion_snowlab.py` | Cohen's Kappa |
| §5 Ético | `docs/marco_etico_legal.md` | 7 secciones |

## Generación de figuras para la tesina

### Diagrama de arquitectura (Mermaid)
```mermaid
graph TB
    CS[Cloud Scheduler 3x/día] --> EX[extractor-clima]
    CS --> MS[monitor-satelital]
    EX --> BQ[(BigQuery clima.*)]
    MS --> BQ
    AZ[analizador-zonas mensual] --> BQ
    BQ --> S1[S1 Topográfico<br/>PINNs + DEM]
    S1 --> S2[S2 Satelital<br/>ViT + MODIS]
    S2 --> S3[S3 Meteorológico<br/>Weather API]
    S3 --> S4[S4 NLP<br/>Relatos]
    S4 --> S5[S5 Integrador<br/>EAWS Matrix]
    S5 --> BOL[Boletín EAWS<br/>24h/48h/72h]
```

### Gráfico de resultados (matplotlib template)
```python
import matplotlib.pyplot as plt
import numpy as np

# Template para gráfico de resultados H1
niveles = ['1-Débil', '2-Moderado', '3-Considerable', '4-Fuerte', '5-Muy Fuerte']
f1_por_nivel = [0.82, 0.71, 0.78, 0.65, 0.90]  # reemplazar con datos reales

fig, ax = plt.subplots(figsize=(8, 5))
bars = ax.bar(niveles, f1_por_nivel, color=['#2ecc71', '#f1c40f', '#e67e22', '#e74c3c', '#8e44ad'])
ax.set_ylabel('F1-Score')
ax.set_title('F1-Score por Nivel EAWS (H1)')
ax.set_ylim(0, 1)
ax.axhline(y=0.75, color='gray', linestyle='--', label='Umbral H1 (75%)')
ax.legend()
plt.tight_layout()
plt.savefig('fig_h1_f1_por_nivel.png', dpi=300)
```

## Checklist pre-entrega

- [ ] ≤25 páginas cuerpo (sin referencias ni anexos)
- [ ] Todas las hipótesis H1-H4 tienen resultados o justificación de pendientes
- [ ] Todas las figuras/tablas referenciadas en el texto
- [ ] Referencias en formato IEEE
- [ ] Revisión ortográfica y gramatical
- [ ] Tutor ha revisado borrador
- [ ] Disclaimer de sistema automatizado visible
