# F5: Despliegue

## Cuándo usar este flujo

Cuando el usuario pide desplegar en producción, actualizar Docker, Cloud Run, o el pipeline CI/CD.

## Arquitectura de despliegue

```
Cloud Build (cloudbuild.yaml)
  → Docker build (Dockerfile)
  → Push a gcr.io/climas-chileno/snow-alert-agentes:TAG
  → Create/update Cloud Run Job: orquestador-avalanchas
```

## Archivos clave

| Archivo | Función |
|---------|---------|
| `agentes/despliegue/Dockerfile` | Imagen del orquestador |
| `agentes/despliegue/cloudbuild.yaml` | Pipeline CI/CD |
| `agentes/despliegue/job_cloud_run.yaml` | Spec del Cloud Run Job |
| `agentes/despliegue/requirements.txt` | Dependencias Python |

## Dockerfile — Puntos importantes

- Base: `python:3.11-slim`
- Copia `agentes/` a `/app/agentes/`
- Copia `datos/analizador_avalanchas/` a `/app/analizador_avalanchas/` (para imports EAWS)
- ENTRYPOINT: `python -m agentes.scripts.generar_todos --guardar`
  - `--guardar` es CRUCIAL: sin él, los boletines no se persisten en BQ+GCS
- Secrets via Secret Manager (no hardcodeados)

## LLM en producción

El sistema usa ClienteDatabricks como LLM principal en producción:
- **Endpoint**: `https://2113388677481041.ai-gateway.cloud.databricks.com/mlflow/v1`
- **Modelo**: `databricks-qwen3-next-80b-a3b-instruct`
- **Token**: GCP Secret Manager `projects/climas-chileno/secrets/databricks-token/versions/latest`

Fallback a Anthropic si Databricks no está disponible (requiere `ANTHROPIC_API_KEY` o `claude-oauth-token`).

## Desplegar paso a paso

### 1. Build y push imagen

```bash
gcloud builds submit \
  --config agentes/despliegue/cloudbuild.yaml \
  --project=climas-chileno
```

El `cloudbuild.yaml` hace create-or-update automático del Cloud Run Job.

### 2. Ejecutar el job

```bash
gcloud run jobs execute orquestador-avalanchas \
  --region=us-central1 \
  --project=climas-chileno
```

### 3. Verificar ejecución

```bash
# Ver logs
gcloud run jobs executions list \
  --job=orquestador-avalanchas \
  --region=us-central1 \
  --project=climas-chileno \
  --limit=3

# Ver boletines generados
bq query --use_legacy_sql=false \
  "SELECT nombre_ubicacion, fecha_emision, nivel_eaws_24h, confianza
   FROM climas-chileno.clima.boletines_riesgo
   ORDER BY fecha_emision DESC LIMIT 10"
```

## Desplegar Cloud Functions (datos)

```bash
cd datos && ./desplegar.sh climas-chileno us-central1
```

Para una función individual:
```bash
gcloud functions deploy monitor-satelital-nieve \
  --gen2 --runtime=python311 --region=us-central1 \
  --source=datos/monitor_satelital/ \
  --entry-point=monitorear_satelital \
  --trigger-http --project=climas-chileno \
  --timeout=540 --memory=1024MB
```

## Checklist pre-despliegue

- [ ] Tests pasan localmente: `python -m pytest agentes/tests/test_subagentes.py -v`
- [ ] `--guardar` presente en ENTRYPOINT del Dockerfile
- [ ] Secret `databricks-token` tiene versión activa en Secret Manager
- [ ] `schema_boletines.json` con 34 campos
- [ ] `almacenador.py` maneja los 34 campos
- [ ] `PROGRESO.md` actualizado

## Troubleshooting

### Error: NameError en almacenador.py
- Verificar que variable se llama `resultado_boletin` (no `resultado`)
- Fix aplicado 2026-03-18

### Error: BUCKET_CLIMA no definida
- Afecta `procesador-clima-horas`
- Fix: `gcloud run services update procesador-clima-horas --update-env-vars BUCKET_CLIMA=climas-chileno-datos-clima-bronce`

### Error: Entry point incorrecto monitor-satelital
- Entry point correcto: `monitorear_satelital` (no `monitorear_nieve`)

### GeoTIFFs vacíos (530 bytes)
- ERA5 pixel ~9-11km necesita ROI > 10km
- Fix: `radio_metros=25000` en descargador.py
