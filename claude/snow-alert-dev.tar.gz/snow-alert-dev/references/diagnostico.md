# F1: Diagnóstico del Sistema

## Cuándo usar este flujo

Cuando el usuario pide: "estado", "validar sistema", "revisar datos", "qué falta", "diagnóstico", o al inicio de una sesión nueva.

## Secuencia de diagnóstico

Ejecutar en este orden. Si algún paso falla, reportar y continuar con los demás.

### Paso 1: Autenticación GCP

```bash
gcloud auth list 2>&1 | head -5
gcloud config get-value project 2>&1
```

- Esperado: cuenta `fpenailillom@correo.uss.cl`, proyecto `climas-chileno`
- Si falla: el usuario necesita `gcloud auth login` y `gcloud config set project climas-chileno`

### Paso 2: Cloud Functions activas

```bash
gcloud functions list --project=climas-chileno --region=us-central1 --gen2 \
  --format="table(name,state,updateTime)" 2>&1
```

Las 6 funciones esperadas:
- `extractor-clima` — Google Weather API → condiciones_actuales
- `procesador-clima` — Pub/Sub → BigQuery
- `procesador-clima-horas` — pronóstico horario (requiere `BUCKET_CLIMA=climas-chileno-datos-clima-bronce`)
- `procesador-clima-dias` — pronóstico diario
- `monitor-satelital-nieve` — GEE MODIS (entry point: `monitorear_satelital`)
- `analizador-satelital-zonas-riesgosas-avalanchas` — GEE SRTM

### Paso 3: Cloud Scheduler

```bash
gcloud scheduler jobs list --location=us-central1 --project=climas-chileno \
  --format="table(name,schedule,state,lastAttemptTime)" 2>&1
```

Jobs esperados:
- `extraer-clima-job` → `0 8,14,20 * * *`
- `analizar-topografia-job` → `0 3 1 * *`
- `monitor-satelital-job` → `30 8,14,20 * * *`

### Paso 4: Cloud Run Job (orquestador)

```bash
gcloud run jobs describe orquestador-avalanchas --region=us-central1 --project=climas-chileno \
  --format="yaml(metadata.name,status)" 2>&1

gcloud run jobs executions list --job=orquestador-avalanchas --region=us-central1 \
  --project=climas-chileno --limit=3 \
  --format="table(name,completionTime,succeeded,failed)" 2>&1
```

### Paso 5: Calidad datos BigQuery

Ejecutar cada query y evaluar:

```bash
# imagenes_satelitales (frescura + nulos NDSI)
bq query --use_legacy_sql=false --project_id=climas-chileno \
'SELECT COUNT(*) total,
  COUNTIF(fecha_captura >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 48 HOUR)) ultimas_48h,
  ROUND(COUNTIF(ndsi_medio IS NULL)/COUNT(*)*100,1) pct_nulos_ndsi,
  MAX(fecha_captura) ultima_captura
FROM `climas-chileno.clima.imagenes_satelitales`'

# zonas_avalancha (pendiente correcta post-fix cubicacion.py)
bq query --use_legacy_sql=false --project_id=climas-chileno \
'SELECT COUNT(*) total,
  ROUND(AVG(pendiente_max_inicio),2) pendiente_max_media,
  ROUND(AVG(indice_riesgo_topografico),2) indice_riesgo_medio
FROM `climas-chileno.clima.zonas_avalancha`'
# pendiente_max_media debe ser >5° (si ≈0° → datos pre-fix, re-ejecutar función)

# condiciones_actuales (frescura meteorológica)
bq query --use_legacy_sql=false --project_id=climas-chileno \
'SELECT COUNT(*) total,
  COUNTIF(hora_actual >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 8 HOUR)) ultimas_8h,
  COUNT(DISTINCT nombre_ubicacion) ubicaciones,
  MAX(hora_actual) ultima
FROM `climas-chileno.clima.condiciones_actuales`'

# boletines_riesgo (output del sistema)
bq query --use_legacy_sql=false --project_id=climas-chileno \
'SELECT COUNT(*) total, MAX(fecha_emision) ultimo
FROM `climas-chileno.clima.boletines_riesgo`'

# relatos_montanistas (NLP — 37 campos)
bq query --use_legacy_sql=false --project_id=climas-chileno \
'SELECT COUNT(*) total,
  COUNTIF(avalanche_priority=TRUE) con_avalancha,
  ROUND(AVG(SAFE_CAST(llm_puntuacion_riesgo AS FLOAT64)),2) riesgo_promedio
FROM `climas-chileno.clima.relatos_montanistas`'
# Esperado: ~3,131 rutas, ~41 con avalanche_priority, riesgo ~4.56

# pronostico_horas y pronostico_dias
bq query --use_legacy_sql=false --project_id=climas-chileno \
'SELECT "horas" tabla, COUNT(*) total, COUNT(DISTINCT nombre_ubicacion) ubic, MAX(fecha_inicio) ultima
FROM `climas-chileno.clima.pronostico_horas`
UNION ALL
SELECT "dias", COUNT(*), COUNT(DISTINCT nombre_ubicacion), MAX(fecha_inicio)
FROM `climas-chileno.clima.pronostico_dias`'
```

### Paso 6: Tests unitarios

```bash
cd snow_alert && python -m pytest agentes/tests/test_subagentes.py -v --tb=short -q 2>&1 | tail -20
```

Esperado: ≥135 passed, 5 skipped (los skip son por falta de ANTHROPIC_API_KEY).

### Paso 7: Imports Python

```bash
cd snow_alert && python3 -c "
import sys; sys.path.insert(0,'.'); sys.path.insert(0,'datos')
try:
    from analizador_avalanchas.eaws_constantes import consultar_matriz_eaws
    n,_=consultar_matriz_eaws('poor','some',2); print(f'eaws_constantes: OK (nivel={n})')
except Exception as e: print(f'eaws_constantes: ERROR {e}')
try:
    from agentes.datos.consultor_bigquery import ConsultorBigQuery; print('consultor_bigquery: OK')
except Exception as e: print(f'consultor_bigquery: ERROR {e}')
try:
    from agentes.orquestador.agente_principal import OrquestadorAvalancha; print('orquestador: OK')
except Exception as e: print(f'orquestador: ERROR {e}')
try:
    from agentes.subagentes.subagente_nlp.agente import SubagenteNLP; print('subagente_nlp: OK')
except Exception as e: print(f'subagente_nlp: ERROR {e}')
"
```

## Formato del reporte

```
═══════════════════════════════════════════════════════════
REPORTE DE ESTADO — snow_alert — [FECHA]
═══════════════════════════════════════════════════════════
DIMENSIÓN                        ESTADO   DETALLE
─────────────────────────────────────────────────────────
1. Auth GCP                        [✅⚠️❌]
2. Cloud Functions (6)             [✅⚠️❌]  N/6 activas
3. Cloud Scheduler (3)             [✅⚠️❌]  N/3 habilitados
4. Cloud Run Job                   [✅⚠️❌]
5. Datos BigQuery (7 tablas)       [✅⚠️❌]  por tabla
6. Tests unitarios                 [✅⚠️❌]  N passed / N failed
7. Imports Python                  [✅⚠️❌]

ESTADO GENERAL: [OPERACIONAL / DEGRADADO / BLOQUEADO]
═══════════════════════════════════════════════════════════
ACCIONES REQUERIDAS: [solo si hay ⚠️ o ❌]
```

Criterio:
- **OPERACIONAL**: ≥5/7 ✅, ninguna ❌ en auth o tests
- **DEGRADADO**: 1-2 ❌ no críticas
- **BLOQUEADO**: ❌ en autenticación o imports
