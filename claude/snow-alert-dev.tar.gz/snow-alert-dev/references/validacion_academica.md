# F4: Validación Académica

## Cuándo usar este flujo

Cuando el usuario trabaja en hipótesis H1-H4, métricas EAWS, notebooks de validación, o análisis estadístico.

## Hipótesis y métricas

### H1: Precisión del sistema multi-agente
- **Métrica**: F1-score macro por nivel EAWS (1-5)
- **Umbral**: ≥ 75%
- **Notebook**: `notebooks_validacion/01_validacion_f1_score.py`
- **Requiere**: ≥50 boletines en `boletines_riesgo` + ground truth CSV
- **Framework**: `agentes/validacion/metricas_eaws.py` → `calcular_f1_macro()`
- **Prueba estadística**: Bootstrap IC 95% (notebook 05)

### H2: Mejora por NLP
- **Métrica**: Delta F1 (con NLP vs sin NLP) por ablación
- **Umbral**: > 5 puntos porcentuales
- **Notebook**: `notebooks_validacion/02_analisis_ablacion.py`
- **Estado**: ✅ Confirmada sintéticamente (+7.9pp, notebook 06)
- **Modelo NLP**: unidireccional — corrección solo hacia arriba (principio precaución, Techel & Schweizer 2017)
- **Prueba estadística**: Test diferencia proporciones (notebook 05)

### H3: Transfer learning SLF
- **Métrica**: QWK (Quadratic Weighted Kappa)
- **Notebook**: pendiente
- **Estado**: Pendiente datos SLF suizos
- **Benchmark**: Techel et al. (2022) → `comparar_con_techel_2022()` en `metricas_eaws.py`

### H4: Concordancia con Snowlab Chile
- **Métrica**: Cohen's Kappa ≥ 0.60
- **Notebook**: `notebooks_validacion/03_comparacion_snowlab.py`
- **Requiere**: Datos de pronósticos manuales de Snowlab
- **Framework**: `metricas_eaws.py` → `calcular_cohens_kappa()`, `calcular_qwk()`
- **Prueba estadística**: McNemar test (notebook 05)

## Framework de métricas (`metricas_eaws.py`)

Ubicación: `agentes/validacion/metricas_eaws.py`

Funciones principales:
- `calcular_f1_macro(y_true, y_pred)` — F1 ponderado por nivel EAWS
- `calcular_cohens_kappa(y_true, y_pred)` — concordancia inter-evaluador
- `calcular_qwk(y_true, y_pred)` — Quadratic Weighted Kappa (ordinal)
- `calcular_accuracy_adyacente(y_true, y_pred)` — accuracy ±1 nivel
- `comparar_con_techel_2022(metricas)` — benchmark vs referencia suiza
- `calcular_ablacion(resultados_completo, resultados_sin_componente)` — delta por componente

Referencia Techel 2022:
```python
TECHEL_2022_REFERENCIA = {
    "accuracy": 0.74,       # ±1 nivel
    "qwk": 0.58,           # Quadratic Weighted Kappa
    "bias": -0.15,          # sesgo negativo (subestimación)
    "n_boletines": 11548
}
```

## Notebooks de validación

| Notebook | Hipótesis | Qué calcula |
|----------|-----------|-------------|
| `01_validacion_f1_score.py` | H1 | F1-macro, matriz confusión, carga ground truth |
| `02_analisis_ablacion.py` | H2 | Ablación con/sin cada subagente, ranking importancia |
| `03_comparacion_snowlab.py` | H4 | Cohen's Kappa, QWK, accuracy ±1, vs Techel |
| `04_confianza_cobertura.py` | — | Cobertura campos, trazabilidad, tiempos |
| `05_pruebas_estadisticas.py` | H1,H2,H4 | Bootstrap IC 95%, McNemar, potencia estadística |
| `06_analisis_nlp_sintetico.py` | H2 | Delta F1 sintético (+7.9pp), sensibilidad, unidireccional |

## Cómo generar datos para validación

### Paso 1: Generar boletines (≥50)
```bash
cd agentes && python scripts/generar_todos.py
# Genera boletines para todas las ubicaciones monitoreadas
# Requiere: ANTHROPIC_API_KEY o Databricks token
```

### Paso 2: Crear ground truth
Para H1, necesitas un CSV con columnas:
```csv
nombre_ubicacion,fecha,nivel_eaws_real
"La Parva Sector Bajo","2026-03-18",3
```
Fuentes de ground truth: Snowlab Chile, CAEX, reportes manuales.

### Paso 3: Ejecutar notebooks
```bash
cd snow_alert
python notebooks_validacion/01_validacion_f1_score.py
python notebooks_validacion/02_analisis_ablacion.py
# etc.
```

## Análisis de potencia (notebook 05)

Para planificar cuántos boletines necesitas:

| Hipótesis | Efecto esperado | N mínimo (α=0.05, β=0.80) |
|-----------|-----------------|----------------------------|
| H1 | F1 ≥ 0.75 | ~50 boletines |
| H2 | Delta > 5pp | ~200 pares (con/sin NLP) |
| H4 | Kappa ≥ 0.60 | ~40 pares (sistema vs humano) |

## Checklist métricas pre-defensa

- [ ] ≥50 boletines generados en `boletines_riesgo`
- [ ] Ground truth disponible (CSV o datos Snowlab)
- [ ] F1-macro calculado con IC 95% bootstrap
- [ ] Ablación NLP: delta F1 con IC 95%
- [ ] Benchmark Techel 2022: QWQ y accuracy ±1 reportados
- [ ] Análisis de potencia documentado para cada hipótesis
