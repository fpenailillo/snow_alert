# F6: Documentación de Tesina

## Cuándo usar este flujo

Cuando el usuario trabaja en la tesina, marco teórico, justificaciones de brechas, decisiones de diseño, o preparación de defensa.

## Contexto académico

- **Programa**: Magíster en Tecnologías de la Información, UTFSM
- **Tutor**: Dr. Mauricio Solar
- **Tema**: Sistema multi-agente serverless para predicción de avalanchas con IA
- **Escala**: EAWS (European Avalanche Warning Services)

## Documentos de la tesina

| Archivo | Contenido |
|---------|-----------|
| `docs/decisiones_diseno.md` | D1-D13: Justificaciones académicas de cada decisión técnica |
| `docs/arquitectura.md` | Diagrama y descripción del pipeline 5 subagentes |
| `docs/marco_etico_legal.md` | Framework ético-legal (Ley 21.719, responsabilidad, gobernanza) |
| `claude/PLAN_BRECHAS_MARCO_TEORICO.md` | Estado de alineación código-teoría (8 dimensiones) |

## Decisiones de diseño documentadas

| ID | Decisión | Justificación | Ref académica |
|----|----------|---------------|---------------|
| D1 | Arquitectura multi-agente vs monolítico | Especialización por dominio, degradación graceful | Wooldridge (2009) |
| D2 | ViT temporal sobre métricas (no imágenes crudas) | Métricas son representaciones densas, atención temporal | Zhou et al. (2021), Vaswani et al. (2017) |
| D3 | PINN vs red neuronal pura | Consistencia física con datos escasos | Raissi et al. (2019) |
| D4 | Clasificación ordinal de capas débiles | Alineación EAWS, umbrales Mohr-Coulomb | Reuter et al. (2022) |
| D5 | NLP como enriquecimiento (no crítico) | Sesgo de selección en relatos, validación heurística | — |
| D6 | Frecuencia base topográfica + ajuste viento | Datos escasos → heurística física | Lehning et al. (2008) |
| D7-D10 | Varias decisiones serverless y BigQuery | Costo, escalabilidad, reproducibilidad | — |
| D11 | Benchmark Techel (2022) | Referencia internacional para H3 | Techel et al. (2022) |
| D12 | Marco ético-legal + principio precaución | Trazabilidad, disclaimer, sesgo conservador | — |
| D13 | UQ PINN (Taylor 1er orden) | IC 95% FS, sensibilidades por parámetro | Saltelli et al. (2008) |

## Auditoría de alineación marco teórico → código

### 8 Dimensiones evaluadas

| # | Dimensión | Score actual | Máx |
|---|-----------|-------------|-----|
| 1 | Arquitectura Multi-Agente | 10 | 10 |
| 2 | PINNs (manto nival) | 9 | 10 |
| 3 | Vision Transformers (ViT) | 8 | 10 |
| 4 | Escala EAWS + Matriz | 9 | 10 |
| 5 | NLP Relatos Montañistas | 8 | 10 |
| 6 | Infraestructura Serverless | 9 | 10 |
| 7 | Métricas de Validación | 9 | 10 |
| 8 | Marco Ético-Legal | 9 | 10 |

**Alineación general: 71/80 (ALTA)**

### Brechas cerradas (todas)
- B1: Tabla `boletines_riesgo` — 34 campos
- B2: Notebooks validación — F1, ablación, Kappa, Techel
- B3: Relatos + ETL + fallback 15 zonas + H2 sintética
- B4: ViT multi-head attention (H=2, W_QKV Xavier, PE sinusoidal)
- B5: PINN gradiente LST real + UQ Taylor
- B6: Tamaño EAWS dinámico + ajuste viento
- B7: zonas_avalancha regenerada (37/37 correctas)
- B8-B11: Justificadas en `docs/decisiones_diseno.md`
- E1: Marco ético-legal completo

## Cómo documentar una nueva decisión

Agregar a `docs/decisiones_diseno.md`:

```markdown
### D[N]: Título de la decisión

**Contexto**: Qué problema resuelve.

**Decisión**: Qué se eligió hacer.

**Alternativas evaluadas**:
1. Alternativa A — por qué se descartó
2. Alternativa B — por qué se descartó

**Justificación académica**: Referencia a papers, principios teóricos.

**Impacto en el código**: Archivos afectados, líneas clave.

**Referencias**:
- Autor et al. (Año). Título. Journal.
```

## Preparación para la defensa

### Preguntas probables del comité

1. **¿Por qué ViT sobre métricas y no sobre imágenes crudas?**
   → D2: eficiencia computacional + métricas son representaciones densas pre-procesadas

2. **¿Cómo justifica el PINN sin entrenamiento real?**
   → D3+D13: ecuaciones físicas (Mohr-Coulomb) como restricción + UQ Taylor con IC 95%

3. **¿El NLP realmente mejora la predicción?**
   → H2: +7.9pp confirmado sintéticamente (notebook 06), modelo unidireccional (precaución)

4. **¿Cómo se compara con sistemas internacionales?**
   → D11: Techel 2022 (QWK=0.58, accuracy±1=74%), nuestro sistema reportar QWK+accuracy

5. **¿Qué pasa si el sistema falla?**
   → Degradación graceful (S4 no-crítico), disclaimer en boletines, marco ético D12

6. **¿Cumple con regulación chilena de datos?**
   → Marco ético `docs/marco_etico_legal.md`: Ley 21.719 (LGPD Chile), gobernanza GCP

### Métricas a reportar en la defensa

| Métrica | Valor | Fuente |
|---------|-------|--------|
| Subagentes implementados | 5/5 | `agente_principal.py` |
| Tools por subagente | 3-4 cada uno | `tools/*.py` |
| Ubicaciones monitoreadas | 84 meteo + 25 satelital + 37 topográfico | BigQuery |
| Relatos analizados | 3,131 | `relatos_montanistas` |
| Campos por boletín | 34 | `schema_boletines.json` |
| Tests unitarios | ≥135 | `test_subagentes.py` |
| Delta NLP (H2) | +7.9pp (sintético) | notebook 06 |
| Tiempo ejecución | ~860s/10 ubicaciones | Cloud Run logs |
| Decisiones documentadas | 13 | `decisiones_diseno.md` |

## Referencias bibliográficas clave

- Vaswani et al. (2017) — Attention Is All You Need
- Zhou et al. (2021) — Informer: Beyond Efficient Transformer
- Raissi et al. (2019) — Physics-informed neural networks
- Techel et al. (2022) — Spatial consistency and bias in avalanche forecasts
- Müller, Techel & Mitterer (2025) — EAWS Matrix
- Proksch et al. (2015) — Snow density parameterization
- Saltelli et al. (2008) — Global Sensitivity Analysis
- Glorot & Bengio (2010) — Xavier initialization
- Lehning et al. (2008) — SNOWPACK model wind transport
- Techel & Schweizer (2017) — Avalanche danger forecasting verification
