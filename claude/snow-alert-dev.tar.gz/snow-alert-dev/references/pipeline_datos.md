# F3: Pipeline de Datos GCP

## Cuándo usar este flujo

Cuando el usuario trabaja con Cloud Functions, BigQuery, GCS, GEE, o el pipeline de recolección de datos.

## Arquitectura de datos

```
Cloud Scheduler (3x/día)
├── extractor-clima → GCS (JSON bruto) → Pub/Sub
│   ├── procesador-clima → BigQuery: condiciones_actuales
│   ├── procesador-clima-horas → BigQuery: pronostico_horas
│   └── procesador-clima-dias → BigQuery: pronostico_dias
├── monitor-satelital-nieve → BigQuery: imagenes_satelitales + GCS (GeoTIFF/previews)
└── analizador-zonas-avalanchas (mensual) → BigQuery: zonas_avalancha
```

## Cloud Functions — Detalles operacionales

### extractor-clima
- **Fuente**: Google Weather API
- **Output**: JSON en GCS `climas-chileno-datos-clima-bronce`
- **Trigger**: Cloud Scheduler `0 8,14,20 * * *`
- **Ubicaciones**: 84 activas

### procesador-clima / procesador-clima-horas / procesador-clima-dias
- **Trigger**: Pub/Sub (activado por extractor-clima)
- **Output**: BigQuery `clima.condiciones_actuales / pronostico_horas / pronostico_dias`
- **NOTA**: `procesador-clima-horas` requiere env var `BUCKET_CLIMA=climas-chileno-datos-clima-bronce`

### monitor-satelital-nieve
- **Entry point**: `monitorear_satelital` (NO `monitorear_nieve`)
- **Fuente**: Google Earth Engine (MODIS NDSI, LST, ERA5, Sentinel-2)
- **Output**: BigQuery `clima.imagenes_satelitales` + GCS GeoTIFFs + previews PNG
- **Ubicaciones**: 25 monitoreadas
- **Productos**: NDSI, LST día/noche, ERA5 snow depth/SWE, viento 100m, Sentinel-2

#### Bugs conocidos y fixes aplicados (2026-03-18)
- `constantes.py`: bandas corregidas (`NDSI_Snow_Cover→NDSI`, `CMI→R/G/B`, vis_params MODIS)
- `metricas.py`: guard NoneType para SAR + args `lst_dia→lst_dia_celsius`
- `productos.py`: NDSI mask `neq(250)→lte(100)`, LST mask fill value 0, `datetime.utcnow()→datetime.now(timezone.utc)`
- `indicadores_nieve.py`: `select('NDSI_Snow_Cover')→select('NDSI')` en snowline y cambio cobertura
- `viento_altura.py`: bandas `u/v_component_of_wind→u/v_component_of_wind_100m`, ventana 24h→7 días
- `descargador.py`: ERA5 GeoTIFF `radio_metros=25000` (pixel ERA5 ~9-11km), tipo_producto en nombre archivo

### analizador-satelital-zonas-riesgosas-avalanchas
- **Fuente**: GEE SRTM 30m DEM
- **Output**: BigQuery `clima.zonas_avalancha` (37 ubicaciones)
- **Fix cubicacion.py**: 12 key mismatches corregidos (pendiente_max→pendiente_max_inicio, etc.)

## Despliegue de Cloud Functions

```bash
cd datos && ./desplegar.sh climas-chileno us-central1
```

Para redesplegar una función individual:
```bash
gcloud functions deploy NOMBRE-FUNCION \
  --gen2 --runtime=python311 --region=us-central1 \
  --source=datos/CARPETA/ --entry-point=FUNCION \
  --trigger-http --project=climas-chileno
```

## Modificar una Cloud Function

⚠️ **REGLA**: NUNCA modificar archivos en `datos/` sin confirmación explícita del usuario.

1. Describir el cambio propuesto y pedir confirmación
2. Hacer el cambio
3. Verificar localmente si es posible
4. Redesplegar: `gcloud functions deploy ...`
5. Forzar ejecución: `gcloud functions call NOMBRE --gen2 --region=us-central1`
6. Verificar datos en BigQuery post-ejecución

## ETL Relatos (datos/relatos/)

Script: `datos/relatos/cargar_relatos.py`

Lee CSVs exportados desde Databricks:
- `andes_handbook_routes.csv` — 3,142 rutas, 22 columnas
- `andes_handbook_routes_llm.csv` — análisis LLM por ruta

Schema: `datos/relatos/schema_relatos.json` — 37 campos

```bash
python datos/relatos/cargar_relatos.py \
  --routes datos/relatos/andes_handbook_routes.csv \
  --llm datos/relatos/andes_handbook_routes_llm.csv
```

## Queries útiles de diagnóstico

```sql
-- Últimas capturas satelitales
SELECT nombre_ubicacion, fecha_captura, ndsi_medio, lst_dia_celsius, pct_nubes
FROM `climas-chileno.clima.imagenes_satelitales`
ORDER BY fecha_captura DESC LIMIT 10;

-- Zonas con riesgo topográfico alto
SELECT nombre_ubicacion, pendiente_max_inicio, indice_riesgo_topografico
FROM `climas-chileno.clima.zonas_avalancha`
WHERE indice_riesgo_topografico > 50
ORDER BY indice_riesgo_topografico DESC;

-- Condiciones meteorológicas recientes
SELECT nombre_ubicacion, hora_actual, temperatura_celsius,
  diurno_velocidad_viento, probabilidad_precipitacion_diurno
FROM `climas-chileno.clima.condiciones_actuales`
WHERE hora_actual >= TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL 8 HOUR)
ORDER BY hora_actual DESC LIMIT 20;

-- Relatos con prioridad avalancha
SELECT route_name, location, elevation, llm_nivel_riesgo, llm_puntuacion_riesgo
FROM `climas-chileno.clima.relatos_montanistas`
WHERE avalanche_priority = TRUE
ORDER BY llm_puntuacion_riesgo DESC;
```
