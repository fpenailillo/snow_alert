# F2: Desarrollo de Agentes

## Cuándo usar este flujo

Cuando el usuario pide modificar, crear o mejorar subagentes, tools, o el orquestador.

## Arquitectura de un subagente

Cada subagente sigue esta estructura:

```
subagente_NOMBRE/
├── __init__.py
├── agente.py       # Clase que hereda de BaseSubagente
├── prompts.py      # System prompt + tool descriptions
└── tools/
    ├── __init__.py
    └── tool_*.py   # Funciones ejecutoras de cada tool
```

### Clase base (BaseSubagente)

Ubicación: `agentes/subagentes/base_subagente.py`

Implementa el agentic loop:
1. Recibe contexto previo del orquestador
2. Envía system prompt + tools al LLM
3. Loop: LLM decide qué tool usar → ejecutar tool → retornar resultado → LLM decide si necesita más
4. Retorna resultado estructurado (dict)

Reintentos: backoff exponencial (3 intentos, 2-30s) en `_llamar_api()`.

### Crear un nuevo tool

```python
# agentes/subagentes/subagente_NOMBRE/tools/tool_ACCION.py

"""
Tool: ACCION
Descripción en español de lo que hace.
"""
import logging
from agentes.datos.consultor_bigquery import ConsultorBigQuery

logger = logging.getLogger(__name__)

def ejecutar_ACCION(parametro1: str, parametro2: float = None) -> dict:
    """Ejecuta la acción X consultando datos de BigQuery.
    
    Args:
        parametro1: Descripción
        parametro2: Descripción (opcional)
    
    Returns:
        dict con claves: resultado, confianza, metadata
    """
    logger.info(f"[NombreSubagente] ACCION → inicio para {parametro1}")
    
    consultor = ConsultorBigQuery()
    
    try:
        datos = consultor.metodo_apropiado(parametro1)
        
        if not datos or datos.get("dato_nulo"):
            logger.warning(f"[NombreSubagente] ACCION → datos nulos para {parametro1}")
            return {
                "resultado": None,
                "dato_nulo": True,
                "confianza": "baja",
                "razon_nulo": "Sin datos disponibles en BigQuery"
            }
        
        # Lógica del tool...
        resultado = _calcular(datos)
        
        logger.info(f"[NombreSubagente] ACCION → {resultado}")
        return {
            "resultado": resultado,
            "confianza": "alta",
            "fuente": "BigQuery clima.tabla_nombre",
            "metadata": {}
        }
        
    except Exception as e:
        logger.error(f"[NombreSubagente] ACCION → error: {e}")
        return {
            "error": str(e),
            "dato_nulo": True,
            "confianza": "baja"
        }
```

### Registrar tool en prompts.py

```python
TOOLS_SUBAGENTE_NOMBRE = [
    {
        "name": "nombre_tool",
        "description": "Descripción en español de lo que hace el tool y cuándo usarlo.",
        "input_schema": {
            "type": "object",
            "properties": {
                "parametro1": {"type": "string", "description": "..."},
                "parametro2": {"type": "number", "description": "..."}
            },
            "required": ["parametro1"]
        }
    }
]
```

### Registrar tool en agente.py

En el método `_ejecutar_tool()`:
```python
if nombre_tool == "nombre_tool":
    from .tools.tool_accion import ejecutar_ACCION
    return ejecutar_ACCION(**argumentos)
```

## Orquestador (agente_principal.py)

El orquestador coordina S1→S2→S3→S4→S5 secuencialmente, pasando contexto acumulado.

Flujo:
1. `_ejecutar_subagente_topografico()` → contexto S1
2. `_ejecutar_subagente_satelital(contexto_s1)` → contexto S2
3. `_ejecutar_subagente_meteorologico(contexto_s1+s2)` → contexto S3
4. `_ejecutar_subagente_nlp(contexto_s1+s2+s3)` → contexto S4
5. `_ejecutar_subagente_integrador(contexto_s1+s2+s3+s4)` → boletín final

**Degradación graceful**: S4 (NLP) es no-crítico. Si falla, el pipeline continúa con `subagentes_degradados` registrado.

## ConsultorBigQuery

Ubicación: `agentes/datos/consultor_bigquery.py`

Centraliza TODAS las consultas a BigQuery. Siempre retorna `dict` (nunca DataFrame).

Métodos existentes:
- `obtener_condiciones_actuales(ubicacion)` → dict con meteorología
- `obtener_pronostico_horas(ubicacion)` → dict con pronóstico horario
- `obtener_pronostico_dias(ubicacion)` → dict con pronóstico diario
- `obtener_imagenes_satelitales(ubicacion)` → dict con NDSI, LST, snowline
- `obtener_zona_avalancha(ubicacion)` → dict con topografía SRTM
- `obtener_relatos(ubicacion)` → dict con relatos Andeshandbook
- `buscar_relatos_por_zona(zona, radio_km)` → dict con relatos cercanos

Para agregar un nuevo método, seguir el patrón existente con timeout 30s.

## Escribir tests

Ubicación: `agentes/tests/test_subagentes.py`

Patrón para tests de tools (sin credenciales externas):

```python
class TestToolsNUEVO(unittest.TestCase):
    """Tests para tools del SubagenteNUEVO."""
    
    def test_tool_basico(self):
        """Verifica que el tool retorna estructura correcta."""
        from agentes.subagentes.subagente_NOMBRE.tools.tool_accion import ejecutar_ACCION
        resultado = ejecutar_ACCION("parametro_test")
        self.assertIsInstance(resultado, dict)
        self.assertIn("resultado", resultado)
        
    def test_tool_datos_nulos(self):
        """Verifica manejo de datos nulos."""
        resultado = ejecutar_ACCION("ubicacion_inexistente")
        self.assertTrue(resultado.get("dato_nulo", False))
        self.assertEqual(resultado["confianza"], "baja")
```

Convención: todos los tests deben poder correr sin GCP auth ni ANTHROPIC_API_KEY. Usar `@unittest.skipIf` para tests que requieran credenciales.

## Checklist antes de commit

- [ ] Tool retorna `dict` con `confianza` y manejo de nulos
- [ ] Logs con formato `[Subagente] operación → resultado`
- [ ] Test unitario del tool sin dependencias externas
- [ ] Tool registrado en `prompts.py` y `agente.py`
- [ ] `PROGRESO.md` actualizado
- [ ] Tests pasan: `python -m pytest agentes/tests/test_subagentes.py -v --tb=short`
