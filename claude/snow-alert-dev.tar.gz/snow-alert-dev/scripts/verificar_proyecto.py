#!/usr/bin/env python3
"""
Verificación rápida del estado del proyecto snow_alert.
Ejecutar al inicio de cada sesión de desarrollo.

Uso:
    python scripts/verificar_proyecto.py [--completo] [--solo-local]

Flags:
    --completo    Incluye verificaciones GCP (requiere auth)
    --solo-local  Solo verificaciones locales (sin GCP)
"""

import os
import sys
import subprocess
import importlib
import json
import argparse
from pathlib import Path
from datetime import datetime


class ColoresTerminal:
    OK = "\033[92m✅"
    WARN = "\033[93m⚠️"
    FAIL = "\033[91m❌"
    RESET = "\033[0m"
    BOLD = "\033[1m"


def c(estado, mensaje):
    """Formatea mensaje con color."""
    return f"{estado} {mensaje}{ColoresTerminal.RESET}"


def encontrar_raiz():
    """Encuentra el directorio raíz de snow_alert."""
    candidatos = [
        os.getcwd(),
        os.path.join(os.getcwd(), "snow_alert"),
        os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    ]
    for d in candidatos:
        if os.path.exists(os.path.join(d, "agentes", "orquestador")):
            return d
    return None


def verificar_estructura(raiz):
    """Verifica que los archivos críticos existen."""
    print(f"\n{ColoresTerminal.BOLD}═══ ESTRUCTURA DEL PROYECTO ═══{ColoresTerminal.RESET}")
    
    archivos_criticos = [
        "agentes/orquestador/agente_principal.py",
        "agentes/datos/consultor_bigquery.py",
        "agentes/salidas/almacenador.py",
        "agentes/salidas/schema_boletines.json",
        "agentes/subagentes/base_subagente.py",
        "agentes/subagentes/subagente_topografico/agente.py",
        "agentes/subagentes/subagente_satelital/agente.py",
        "agentes/subagentes/subagente_meteorologico/agente.py",
        "agentes/subagentes/subagente_nlp/agente.py",
        "agentes/subagentes/subagente_integrador/agente.py",
        "datos/analizador_avalanchas/eaws_constantes.py",
        "agentes/despliegue/Dockerfile",
        "claude/PROGRESO.md",
    ]
    
    faltantes = []
    for archivo in archivos_criticos:
        ruta = os.path.join(raiz, archivo)
        if os.path.exists(ruta):
            pass  # no imprimir todos los OK
        else:
            faltantes.append(archivo)
            print(c(ColoresTerminal.FAIL, f"Falta: {archivo}"))
    
    if not faltantes:
        print(c(ColoresTerminal.OK, f"Todos los {len(archivos_criticos)} archivos críticos presentes"))
    
    # Verificar schema boletines
    schema_path = os.path.join(raiz, "agentes/salidas/schema_boletines.json")
    if os.path.exists(schema_path):
        with open(schema_path) as f:
            schema = json.load(f)
        n_campos = len(schema) if isinstance(schema, list) else len(schema.get("fields", schema.get("schema", [])))
        if n_campos >= 34:
            print(c(ColoresTerminal.OK, f"Schema boletines: {n_campos} campos"))
        else:
            print(c(ColoresTerminal.WARN, f"Schema boletines: {n_campos} campos (esperados ≥34)"))
    
    return len(faltantes) == 0


def verificar_imports(raiz):
    """Verifica que los imports Python funcionan."""
    print(f"\n{ColoresTerminal.BOLD}═══ IMPORTS PYTHON ═══{ColoresTerminal.RESET}")
    
    sys.path.insert(0, raiz)
    sys.path.insert(0, os.path.join(raiz, "datos"))
    
    modulos = {
        "eaws_constantes": "analizador_avalanchas.eaws_constantes",
        "consultor_bigquery": "agentes.datos.consultor_bigquery",
        "orquestador": "agentes.orquestador.agente_principal",
        "subagente_nlp": "agentes.subagentes.subagente_nlp.agente",
        "metricas_eaws": "agentes.validacion.metricas_eaws",
    }
    
    ok_count = 0
    for nombre, modulo in modulos.items():
        try:
            importlib.import_module(modulo)
            print(c(ColoresTerminal.OK, f"{nombre}"))
            ok_count += 1
        except Exception as e:
            print(c(ColoresTerminal.FAIL, f"{nombre}: {e}"))
    
    # Test funcional EAWS
    try:
        from analizador_avalanchas.eaws_constantes import consultar_matriz_eaws
        nivel, _ = consultar_matriz_eaws("poor", "some", 2)
        print(c(ColoresTerminal.OK, f"EAWS funcional: consultar_matriz_eaws('poor','some',2) → nivel {nivel}"))
    except Exception as e:
        print(c(ColoresTerminal.FAIL, f"EAWS funcional: {e}"))
    
    return ok_count == len(modulos)


def verificar_tests(raiz):
    """Ejecuta tests rápidos."""
    print(f"\n{ColoresTerminal.BOLD}═══ TESTS UNITARIOS ═══{ColoresTerminal.RESET}")
    
    test_file = os.path.join(raiz, "agentes/tests/test_subagentes.py")
    if not os.path.exists(test_file):
        print(c(ColoresTerminal.FAIL, "test_subagentes.py no encontrado"))
        return False
    
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pytest", test_file, "-v", "--tb=short", "-q",
             "-k", "TestTools"],
            capture_output=True, text=True, timeout=120,
            cwd=raiz
        )
        
        # Extraer resumen
        for line in result.stdout.split("\n")[-5:]:
            if "passed" in line or "failed" in line or "error" in line:
                if "failed" in line or "error" in line:
                    print(c(ColoresTerminal.FAIL, line.strip()))
                else:
                    print(c(ColoresTerminal.OK, line.strip()))
                return "failed" not in line and "error" not in line
        
        print(c(ColoresTerminal.WARN, "No se pudo interpretar resultado de tests"))
        return False
        
    except subprocess.TimeoutExpired:
        print(c(ColoresTerminal.WARN, "Tests timeout (>120s)"))
        return False
    except Exception as e:
        print(c(ColoresTerminal.FAIL, f"Error ejecutando tests: {e}"))
        return False


def verificar_progreso(raiz):
    """Lee PROGRESO.md y muestra resumen."""
    print(f"\n{ColoresTerminal.BOLD}═══ PROGRESO ═══{ColoresTerminal.RESET}")
    
    progreso_path = os.path.join(raiz, "claude/PROGRESO.md")
    if not os.path.exists(progreso_path):
        print(c(ColoresTerminal.FAIL, "PROGRESO.md no encontrado"))
        return
    
    with open(progreso_path) as f:
        contenido = f.read()
    
    # Extraer última actualización
    for line in contenido.split("\n"):
        if "Última actualización" in line:
            print(c(ColoresTerminal.OK, line.strip("# ").strip()))
            break
    
    # Contar fases completadas
    fases_ok = contenido.count("[x] Fase")
    fases_total = contenido.count("Fase  ") + contenido.count("Fase -1")
    print(c(ColoresTerminal.OK, f"Fases completadas: {fases_ok}"))
    
    # Buscar tests
    for line in contenido.split("\n"):
        if "passed" in line and "test_subagentes" in line:
            print(c(ColoresTerminal.OK, f"Tests registrados: {line.strip('- ✅ ').strip()}"))
            break


def verificar_gcp():
    """Verifica autenticación y recursos GCP."""
    print(f"\n{ColoresTerminal.BOLD}═══ GCP ═══{ColoresTerminal.RESET}")
    
    # Auth
    try:
        result = subprocess.run(
            ["gcloud", "auth", "list", "--format=value(account)", "--filter=status:ACTIVE"],
            capture_output=True, text=True, timeout=10
        )
        cuenta = result.stdout.strip()
        if cuenta:
            print(c(ColoresTerminal.OK, f"Cuenta activa: {cuenta}"))
        else:
            print(c(ColoresTerminal.FAIL, "Sin cuenta GCP activa"))
            return False
    except Exception as e:
        print(c(ColoresTerminal.FAIL, f"gcloud no disponible: {e}"))
        return False
    
    # Proyecto
    try:
        result = subprocess.run(
            ["gcloud", "config", "get-value", "project"],
            capture_output=True, text=True, timeout=10
        )
        proyecto = result.stdout.strip()
        if proyecto == "climas-chileno":
            print(c(ColoresTerminal.OK, f"Proyecto: {proyecto}"))
        else:
            print(c(ColoresTerminal.WARN, f"Proyecto: {proyecto} (esperado: climas-chileno)"))
    except Exception:
        pass
    
    # Cloud Functions
    try:
        result = subprocess.run(
            ["gcloud", "functions", "list", "--project=climas-chileno",
             "--region=us-central1", "--gen2", "--format=value(name,state)"],
            capture_output=True, text=True, timeout=15
        )
        funciones = [l for l in result.stdout.strip().split("\n") if l]
        activas = sum(1 for f in funciones if "ACTIVE" in f)
        print(c(
            ColoresTerminal.OK if activas >= 6 else ColoresTerminal.WARN,
            f"Cloud Functions: {activas}/6 activas"
        ))
    except Exception as e:
        print(c(ColoresTerminal.WARN, f"Cloud Functions: no se pudo verificar ({e})"))
    
    return True


def main():
    parser = argparse.ArgumentParser(description="Verificación rápida snow_alert")
    parser.add_argument("--completo", action="store_true", help="Incluir verificaciones GCP")
    parser.add_argument("--solo-local", action="store_true", help="Solo verificaciones locales")
    args = parser.parse_args()
    
    print(f"\n{'='*60}")
    print(f" VERIFICACIÓN snow_alert — {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    print(f"{'='*60}")
    
    raiz = encontrar_raiz()
    if not raiz:
        print(c(ColoresTerminal.FAIL, "No se encontró directorio snow_alert"))
        sys.exit(1)
    
    print(c(ColoresTerminal.OK, f"Raíz: {raiz}"))
    
    resultados = {}
    
    resultados["estructura"] = verificar_estructura(raiz)
    resultados["imports"] = verificar_imports(raiz)
    verificar_progreso(raiz)
    resultados["tests"] = verificar_tests(raiz)
    
    if args.completo and not args.solo_local:
        resultados["gcp"] = verificar_gcp()
    
    # Resumen
    print(f"\n{'='*60}")
    ok = sum(1 for v in resultados.values() if v)
    total = len(resultados)
    
    if ok == total:
        print(c(ColoresTerminal.OK, f"ESTADO: OPERACIONAL ({ok}/{total} dimensiones OK)"))
    elif ok >= total - 1:
        print(c(ColoresTerminal.WARN, f"ESTADO: DEGRADADO ({ok}/{total} dimensiones OK)"))
    else:
        print(c(ColoresTerminal.FAIL, f"ESTADO: BLOQUEADO ({ok}/{total} dimensiones OK)"))
    
    print(f"{'='*60}\n")


if __name__ == "__main__":
    main()
