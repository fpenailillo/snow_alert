#!/usr/bin/env python3
"""
Utilidad para agregar entradas al PROGRESO.md de forma consistente.

Uso:
    python scripts/actualizar_progreso.py "Descripción de lo completado"
    python scripts/actualizar_progreso.py --seccion "Cambios 2026-03-19" "Descripción"
    python scripts/actualizar_progreso.py --tests 140 5  # 140 passed, 5 skipped
"""

import argparse
import os
import re
from datetime import datetime


def leer_progreso(ruta: str) -> str:
    """Lee el archivo PROGRESO.md."""
    if not os.path.exists(ruta):
        return ""
    with open(ruta, "r", encoding="utf-8") as f:
        return f.read()


def agregar_entrada(contenido: str, entrada: str, seccion: str = None) -> str:
    """Agrega una entrada al PROGRESO.md.
    
    Si se especifica sección, la busca o crea. Si no, agrega al final
    de la última sección de 'Completado'.
    """
    fecha_hoy = datetime.now().strftime("%Y-%m-%d")
    linea = f"- ✅ {entrada} ({fecha_hoy})"
    
    if seccion:
        # Buscar la sección específica
        patron = re.compile(rf"(## {re.escape(seccion)}.*?)(\n## |\Z)", re.DOTALL)
        match = patron.search(contenido)
        if match:
            # Agregar al final de la sección existente
            pos = match.end(1)
            contenido = contenido[:pos] + f"\n{linea}" + contenido[pos:]
        else:
            # Crear nueva sección al final
            contenido += f"\n\n## {seccion}\n\n{linea}\n"
    else:
        # Buscar última sección "Completado"
        patron = re.compile(r"(## Completado.*?)(\n## |\Z)", re.DOTALL)
        matches = list(patron.finditer(contenido))
        if matches:
            ultimo = matches[-1]
            pos = ultimo.end(1)
            contenido = contenido[:pos] + f"\n{linea}" + contenido[pos:]
        else:
            contenido += f"\n{linea}\n"
    
    # Actualizar fecha de última actualización
    contenido = re.sub(
        r"## Última actualización: .*",
        f"## Última actualización: {fecha_hoy}",
        contenido
    )
    
    return contenido


def actualizar_tests(contenido: str, passed: int, skipped: int = 0) -> str:
    """Actualiza el conteo de tests en PROGRESO.md."""
    fecha_hoy = datetime.now().strftime("%Y-%m-%d")
    
    # Buscar y reemplazar línea de tests
    patron = r"(test_subagentes\.py \(sin Anthropic\):) .*"
    reemplazo = f"\\1 ✅ {passed} passed, {skipped} skipped"
    contenido = re.sub(patron, reemplazo, contenido)
    
    return contenido


def main():
    parser = argparse.ArgumentParser(description="Actualizar PROGRESO.md")
    parser.add_argument("entrada", nargs="?", help="Descripción de lo completado")
    parser.add_argument("--seccion", "-s", help="Sección donde agregar")
    parser.add_argument("--tests", "-t", nargs=2, type=int, 
                        metavar=("PASSED", "SKIPPED"),
                        help="Actualizar conteo de tests")
    parser.add_argument("--ruta", "-r", default="log_claude.md",
                        help="Ruta al log_claude.md (antes PROGRESO.md)")
    
    args = parser.parse_args()
    
    # Buscar PROGRESO.md subiendo directorios si es necesario
    ruta = args.ruta
    if not os.path.exists(ruta):
        # Intentar desde snow_alert/
        for prefijo in [".", "..", "../.."]:
            candidato = os.path.join(prefijo, ruta)
            if os.path.exists(candidato):
                ruta = candidato
                break
    
    contenido = leer_progreso(ruta)
    
    if not contenido:
        print(f"⚠️  No se encontró {ruta}")
        return
    
    if args.tests:
        contenido = actualizar_tests(contenido, args.tests[0], args.tests[1])
        print(f"✅ Tests actualizados: {args.tests[0]} passed, {args.tests[1]} skipped")
    
    if args.entrada:
        contenido = agregar_entrada(contenido, args.entrada, args.seccion)
        print(f"✅ Entrada agregada: {args.entrada}")
    
    with open(ruta, "w", encoding="utf-8") as f:
        f.write(contenido)
    
    print(f"📝 {ruta} actualizado")


if __name__ == "__main__":
    main()
