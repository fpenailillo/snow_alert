---
name: snow-alert-dev
description: Framework de desarrollo para el sistema AndesAI/snow_alert — predicción de avalanchas con IA multi-agente sobre GCP. Usar siempre que se trabaje en el proyecto snow_alert, incluyendo: desarrollo de subagentes (topográfico, satelital, meteorológico, NLP, integrador), pipeline de datos GCP (Cloud Functions, BigQuery, Cloud Storage, GEE), validación académica (hipótesis H1-H4, métricas EAWS, notebooks), despliegue Cloud Run, y documentación de tesina. También activar cuando se mencione: avalanchas, EAWS, PINNs, Vision Transformers, boletines de riesgo, Andeshandbook, Snowlab, o cualquier componente del sistema multi-agente. Este skill es el punto de entrada principal para TODO el trabajo de desarrollo del proyecto.
---

# Snow Alert Development Framework

Framework de desarrollo para el sistema AndesAI/snow_alert. Este skill guía todo el ciclo de desarrollo: desde diagnóstico del estado actual hasta código, tests, despliegue y documentación académica.

## Lectura obligatoria al inicio

Antes de escribir cualquier código, ejecuta esta secuencia:

```bash
# 1. Estado del proyecto
cat claude/PROGRESO.md 2>/dev/null | tail -80

# 2. Plan de brechas vigente
cat claude/PLAN_BRECHAS_MARCO_TEORICO.md 2>/dev/null | head -60

# 3. Tests actuales
cd snow_alert && python -m pytest agentes/tests/test_subagentes.py -v --tb=short -q 2>&1 | tail -20

# 4. Reportar estado antes de escribir código
```

Si alguno de estos archivos no se encuentra, buscar en `references/proyecto_estado.md` dentro del skill.

---

## Flujos de trabajo

Este skill soporta 6 flujos principales. Identifica cuál aplica según lo que pide el usuario:

| Flujo | Trigger | Referencia |
|-------|---------|------------|
| **F1: Diagnóstico** | "estado", "validar", "revisar", "qué falta" | `references/diagnostico.md` |
| **F2: Desarrollo agentes** | "subagente", "tool", "agente", "pipeline" | `references/desarrollo_agentes.md` |
| **F3: Pipeline datos** | "Cloud Function", "BigQuery", "GEE", "satelital", "monitor" | `references/pipeline_datos.md` |
| **F4: Validación académica** | "hipótesis", "H1", "H2", "H3", "H4", "métricas", "F1-score", "Kappa" | `references/validacion_academica.md` |
| **F5: Despliegue** | "deploy", "Cloud Run", "Docker", "producción" | `references/despliegue.md` |
| **F6: Documentación tesina** | "tesina", "marco teórico", "brecha", "justificar", "defensa" | `references/documentacion_tesina.md` |
| **F7: Escritura informe** | "escribir capítulo", "redactar sección", "informe final", "formato IEEE" | `references/escritura_tesina.md` |

Lee el archivo de referencia correspondiente antes de ejecutar el flujo.

---

## Reglas fundamentales (aplican SIEMPRE)

### Código
- **Todo en español**: variables, funciones, clases, comentarios, docstrings, logs, mensajes de error
- Tipo de retorno `ConsultorBigQuery`: siempre `dict`, nunca `DataFrame`
- Excepciones: `ErrorSubagente`, `ErrorOrquestador`, `ErrorConexionBigQuery`, `ErrorAlmacenamiento`
- Formato logging: `[NombreSubagente] operación → resultado`
- Manejo explícito de nulos: nunca fallar silenciosamente, documentar con `"dato_nulo": True`
- Timeout 30s por query BigQuery
- No duplicar `EAWS_MATRIX` — importar de `datos/analizador_avalanchas/eaws_constantes.py`

### Import de eaws_constantes.py
```python
import sys, os
_ROOT = os.path.join(os.path.dirname(__file__), '../../../..')  # ajustar niveles
sys.path.insert(0, _ROOT)
sys.path.insert(0, os.path.join(_ROOT, 'datos'))
from analizador_avalanchas.eaws_constantes import consultar_matriz_eaws, NIVELES_PELIGRO
```

### Seguridad y despliegue
- NUNCA hardcodear credenciales — usar Secret Manager o variables de entorno
- NUNCA modificar archivos dentro de `datos/` sin confirmación explícita del usuario
- En Docker, `analizador_avalanchas/` se copia a `/app/analizador_avalanchas/`

### Progreso
- SIEMPRE actualizar `claude/PROGRESO.md` al terminar cada tarea significativa
- NUNCA avanzar de fase sin que los tests de la anterior pasen
- Los boletines deben tener TODAS las secciones del formato aunque falten datos
- El nivel 72h es siempre ≥ nivel 24h (degradación conservadora)

---

## Estructura del proyecto

```
snow_alert/
├── datos/          ← Cloud Functions GCP (NO modificar sin confirmación)
│   ├── extractor/               # Google Weather API → condiciones_actuales
│   ├── procesador/              # Pub/Sub → BigQuery
│   ├── procesador_horas/        # pronóstico horario
│   ├── procesador_dias/         # pronóstico diario
│   ├── monitor_satelital/       # GEE MODIS → imagenes_satelitales
│   ├── analizador_avalanchas/   # GEE SRTM → zonas_avalancha (eaws_constantes.py)
│   └── relatos/                 # ETL Andeshandbook → relatos_montanistas
├── agentes/        ← Desarrollo principal
│   ├── datos/consultor_bigquery.py
│   ├── subagentes/base_subagente.py
│   ├── subagentes/subagente_topografico/    # S1: PINN + DEM
│   ├── subagentes/subagente_satelital/      # S2: ViT + NDSI
│   ├── subagentes/subagente_meteorologico/  # S3: Weather API
│   ├── subagentes/subagente_nlp/            # S4: Relatos + conocimiento andino
│   ├── subagentes/subagente_integrador/     # S5: EAWS + boletín
│   ├── orquestador/agente_principal.py
│   ├── salidas/almacenador.py + schema_boletines.json
│   ├── validacion/metricas_eaws.py
│   ├── despliegue/Dockerfile + cloudbuild.yaml
│   ├── scripts/generar_boletin.py + generar_todos.py
│   └── tests/
├── notebooks_validacion/   # Notebooks H1-H4
├── docs/                   # Documentación académica
└── claude/                 # Guías de sesión
```

---

## Pipeline de 5 subagentes

| # | Subagente | Técnica | Tools | Output clave |
|---|-----------|---------|-------|--------------|
| S1 | Topográfico | PINNs + DEM SRTM + UQ Taylor | dem, pinn, zonas, estabilidad | `clase_estabilidad_eaws`, IC 95% FS |
| S2 | Satelital | ViT multi-head (H=2) + MODIS/GEE | ndsi, vit, anomalias, snowline | `alertas_satelitales`, `anomalia_score` |
| S3 | Meteorológico | Google Weather API + tendencias | condiciones, tendencia, pronostico, ventanas | `ventanas_criticas` |
| S4 | NLP Relatos | Búsqueda semántica + base andina 15 zonas | buscar, extraer, conocimiento | `indice_riesgo_historico` |
| S5 | Integrador | Matriz EAWS 2025 (Müller, Techel & Mitterer) | clasificar, boletin, explicar | Boletín EAWS 24h/48h/72h |

---

## GCP — Recursos del proyecto

| Recurso | Valor |
|---------|-------|
| Proyecto | `climas-chileno` |
| Cuenta | `fpenailillom@correo.uss.cl` |
| Dataset BigQuery | `clima` |
| Bucket GCS | `climas-chileno-datos-clima-bronce` |
| Service Account | `funciones-clima-sa@climas-chileno.iam.gserviceaccount.com` |
| Cloud Run Job | `orquestador-avalanchas` en `us-central1` |
| Secret Claude | `claude-oauth-token` en Secret Manager |
| Secret Databricks | `databricks-token` en Secret Manager |

---

## Tablas BigQuery (`climas-chileno.clima.*`)

| Tabla | Campos clave | Frecuencia |
|-------|-------------|------------|
| `condiciones_actuales` | hora_actual, temperatura, humedad, viento | 3x/día |
| `pronostico_horas` | fecha_inicio, temperatura, precipitacion | 3x/día |
| `pronostico_dias` | fecha_inicio, temp_max, temp_min | 3x/día |
| `imagenes_satelitales` | ndsi_medio, lst_dia/noche, snowline, pct_nubes | 3x/día |
| `zonas_avalancha` | pendiente_max_inicio, indice_riesgo_topografico | mensual |
| `relatos_montanistas` | route_id, avalanche_priority, llm_puntuacion_riesgo | estático (3,131 rutas) |
| `boletines_riesgo` | nivel_eaws_24h/48h/72h, confianza, 34 campos | bajo demanda |

---

## Comandos frecuentes

```bash
# Tests unitarios (sin credenciales)
cd snow_alert && python -m pytest agentes/tests/test_subagentes.py -v -k "TestTools"

# Boletín de prueba
cd agentes && python scripts/generar_boletin.py --ubicacion "La Parva Sector Bajo"

# Diagnóstico datos
python agentes/diagnostico/revisar_datos.py

# Forzar Cloud Functions
gcloud functions call monitor-satelital-nieve --gen2 --region=us-central1
gcloud functions call analizador-satelital-zonas-riesgosas-avalanchas --gen2 --region=us-central1

# Cloud Run Job
gcloud run jobs execute orquestador-avalanchas --region=us-central1

# Desplegar agentes
gcloud builds submit --config agentes/despliegue/cloudbuild.yaml --project=climas-chileno

# Ver boletines
bq query --use_legacy_sql=false \
  "SELECT nombre_ubicacion, fecha_emision, nivel_eaws_24h, confianza
   FROM climas-chileno.clima.boletines_riesgo ORDER BY fecha_emision DESC LIMIT 10"
```

---

## Hipótesis de investigación

| ID | Hipótesis | Métrica | Umbral | Estado |
|----|-----------|---------|--------|--------|
| H1 | Sistema multi-agente alcanza precisión EAWS | F1-macro | ≥ 75% | Pendiente (≥50 boletines) |
| H2 | NLP mejora precisión vs sin NLP | Delta F1 ablación | > 5pp | ✅ Confirmada sintéticamente (+7.9pp) |
| H3 | Transfer learning SLF supera solo-chileno | QWK | — | Pendiente datos SLF |
| H4 | Concordancia con Snowlab Chile | Cohen's Kappa | ≥ 0.60 | Pendiente datos Snowlab |
