# EAWS Matrix 2025 — Referencia Detallada

> Fuente: Müller, Techel & Mitterer (2025), Nat. Hazards Earth Syst. Sci., 25, 4503–4525.
> Documento oficial: EAWS Working Group Matrix and Scale, updated May 2025.

---

## Matriz completa (Figure 3b del paper — versión post testing operacional)

Formato: `D1 (D2)` donde D1 = nivel primario, D2 = nivel secundario en paréntesis.
Celdas sin color (poca evidencia) marcadas con `*`.

### Panel 1: Very poor stability

| Frecuencia \ Tamaño | 5 | 4 | 3 | 2 | 1 |
|---------------------|---|---|---|---|---|
| **Many** | 5 | 5(4) | 4 | 3(4) | 2(3) |
| **Some** | 5(4) | 4 | 3(4) | 3 | 2 |
| **A few** | 4 | 3(4) | 3 | 2 | 1(2) |
| **(Nearly) none** | → Refer to poor stability |

### Panel 2: Poor stability

| Frecuencia \ Tamaño | 5 | 4 | 3 | 2 | 1 |
|---------------------|---|---|---|---|---|
| **Many** | 5(4) | 4 | 4(3) | 3 | 2 |
| **Some** | 4 | 4(3) | 3 | 2(3) | 2 |
| **A few** | 3(4) | 3 | 2(3) | 2 | 1 |
| **(Nearly) none** | → Refer to fair stability |

### Panel 3: Fair stability

| Frecuencia \ Tamaño | 5 | 4 | 3 | 2 | 1 |
|---------------------|---|---|---|---|---|
| **Many** | 4(3)* | 3(4) | 3(2) | 2 | 1(2) |
| **Some** | 3(4) | 3 | 2(3) | 2 | 1(2) |
| **A few** | 3 | 2(3) | 2(1) | 1(2) | 1 |
| **(Nearly) none** | → Danger level 1 (Low) |

`*` = celda sin color en la matriz oficial (< 80% de respuestas en encuesta)

Si stability = **good** → nivel automáticamente **1 (Low)**.

---

## Valores de la encuesta (76 forecasters, 12 países europeos)

### Acuerdo por celda (proporción que eligió D1)

Las celdas con **mayor acuerdo** (>85%):
- fair–a few–size 1 → D=1 (97% acuerdo)
- very poor–many–size 5 → D=5 (99% acuerdo)
- very poor–many–size 3 → D=4 (85% acuerdo)
- poor–some–size 3 → D=3 (84% acuerdo)

Las celdas con **menor acuerdo** (≤55%):
- fair–a few–size 4: bajo acuerdo, combinación poco plausible
- very poor–some–size 3: D1=3 pero 34% eligió otro nivel

**Promedio de acuerdo**: 67% para D1 en todas las celdas.

### Participación por país (N=76 total)

| País | N | País | N |
|------|---|------|---|
| Italia | 18 | Noruega | 15 |
| Suiza | 8 | Francia | 7 |
| Gran Bretaña | 7 | Alemania | 5 |
| España | 5 | Austria | 4 |
| Andorra | 3 | Suecia | 2 |
| Rumania | 1 | Eslovenia | 1 |

Se observaron diferencias "culturales": forecasters escoceses asignaron 5 celdas con D=5, mientras noruegos y suizos solo 2 celdas con D=5.

---

## Cambios de la versión survey a la versión final (post testing operacional)

### Celdas sin color eliminado (a-c en Figure 3a)
- Células raramente usadas (<1% en operación) Y bajo soporte en encuesta (≤80%)
- Se les removió el color de fondo para indicar incertidumbre

### Celdas con D2 eliminado (d-g en Figure 3a)
- Células que en la práctica se usaron casi exclusivamente para un solo nivel
- Se removió el nivel secundario en paréntesis

---

## Versión compacta (ADAM-style, Figure 6 del paper)

La matriz se puede reorganizar según el flujo CMAH separando likelihood (estabilidad × frecuencia) de consecuencias (tamaño).

### Stability Matrix (a)

| Stability \ Frequency | Few | Some | Many |
|-----------------------|-----|------|------|
| **Very poor** | D | B | A |
| **Poor** | E | C | B |
| **Fair** | F | E | D |

### Danger Matrix (b)

| Letra | Tamaño 1 | Tamaño 2 | Tamaño 3 | Tamaño 4 | Tamaño 5 |
|-------|----------|----------|----------|----------|----------|
| **A** | 2(3) | 3(4) | 4 | 5(4) | 5 |
| **B** | 2 | 3 | 4(3) | 4 | 5(4) |
| **C** | 2 | 2(3) | 3 | 4(3) | 4 |
| **D** | 1(2) | 2 | 3 | 3(4) | 4 |
| **E** | 1 | 2 | 2(3) | 3 | 3(4) |
| **F** | 1 | 1(2) | 2(1) | 2(3) | 3 |

Las filas "very similar" (diferencia ≤1 nivel entre todos los tamaños) se fusionan:
- VpMa y PMa → A (very similar)
- VpFe y FMa → D (very similar)
- FSo y PFe → E (very similar)

---

## Tipos de problemas de avalancha (EAWS 2022)

| Problema | Descripción | Estabilidad típica |
|----------|-------------|-------------------|
| New snow | Nieve nueva inestable | poor a very poor |
| Wind slab | Placa de viento | poor a very poor |
| Persistent weak layer | Capa débil persistente | poor a fair |
| Wet snow | Nieve húmeda | very poor (natural) |
| Glide snow | Nieve de deslizamiento | very poor (natural) |

**Nota**: La matriz es más adecuada para problemas dry-snow (new snow, wind slab, persistent weak layer). Para wet-snow y glide-snow hay tendencia a asignar un nivel más bajo para la misma combinación de factores.

---

## Relación con CMAH (Conceptual Model of Avalanche Hazard)

| Concepto CMAH | Equivalente EAWS Matrix |
|---------------|------------------------|
| Sensitivity to triggers | Snowpack stability (very poor→good) |
| Spatial distribution | Frequency distribution (many→none) |
| Likelihood of avalanches | Combinación de stability + frequency |
| Destructive size | Avalanche size (1-5) |

**Diferencia clave**: CMAH describe la distribución espacial del problema de avalancha, mientras EAWS Matrix se centra en la frecuencia de puntos con la estabilidad más débil. Traducir directamente distribución espacial → frecuencia puede sobreestimar la frecuencia.

---

## Limitaciones reconocidas (Sección 6.3 del paper)

1. **Frequency class "some" es demasiado amplia** — las interfaces con "a few" y "many" son difusas
2. **~50% de las celdas tienen D2** — indican que no hay consenso completo
3. **Celdas problemáticas recurrentes**:
   - `very poor–some–size 3`: oscila entre D=3 y D=4
   - `poor–some–size 2`: oscila entre D=2 y D=3
4. **La fiabilidad de estimar los factores de entrada es el factor limitante** para mejorar la consistencia (Techel et al., 2024)
5. **Diferencias culturales** entre warning services afectan la asignación
6. **La EADS actual diverge de la terminología de la matriz** — revisión necesaria

---

## Datos cuantitativos útiles para la tesina

### Frecuencia de estabilidad (Rutschblock, Techel et al. 2020b)
- **None or nearly none**: 0%
- **A few**: >0% – <4%
- **Some**: 4% – 20%
- **Many**: >20%

### Actividad avalancharia (datos Davos 15 años)
- **A few**: <0.02% de zonas de inicio activas
- **Some**: 0.02 – 2.2%
- **Many**: >2.2%

### Eventos nivel 5 (Alpes suizos)
- 1999: 17% del área activa
- 2018: 11%
- 2019: 6%
- Estos valores representan "many" en la clasificación

### Estadísticas de la encuesta
- 76 respuestas de 12 países europeos
- Promedio: cada participante respondió 85% de las 45 combinaciones posibles
- Estabilidad very poor y poor: ≥95% de participación en 17/30 combinaciones
- Estabilidad fair: participación ≥82% para sizes 1-3, pero ≤66% para size 4 y ≤50% para size 5

---

## Implicaciones para AndesAI

1. **La implementación actual de `eaws_constantes.py` debe alinearse con Figure 3b** (versión post testing, no la versión survey Figure 3a)
2. **El ajuste por viento** (>40km/h → +1 freq, >70km/h → +2) es consistente con el concepto de wind slab en EAWS
3. **El tamaño dinámico** (`estimar_tamano_potencial()`) es correcto: el paper confirma que se debe estimar el mayor tamaño esperado
4. **Para wet-snow y glide-snow**: considerar asignar un nivel más bajo que dry-snow para la misma combinación (tendencia observada en operación)
5. **La clase "some" es inherentemente ambigua**: esto justifica que el sistema use D2 (nivel secundario) cuando la frecuencia es "some"
6. **Benchmark**: Techel et al. (2022) QWK=0.58, accuracy±1=74% — el paper confirma que estos son los estándares de referencia
