# Evidencia e Indicadores de Estabilidad EAWS

> Extraído de los Apéndices A del documento EAWS 2025 y del paper Müller et al. (2025).
> Útil para: implementar lógica de clasificación de estabilidad en los subagentes.

---

## Dry snow — Evidencia por clase de estabilidad

| Indicador | Very poor | Poor | Fair | Good |
|-----------|-----------|------|------|------|
| **Liberación natural** | ✅ Sí | — | — | — |
| **Whumpf largo** | ✅ | ✅ | — | — |
| **Whumpf corto** | — | — | ✅ | — |
| **Grietas de tiro (shooting cracks)** | ✅ | ✅ | — | — |
| **Carga baja** (esquiador solo sin caer) | — | ✅ | — | — |
| **Carga alta** (esquiador cayendo, grupo) | — | — | ✅ | — |
| **Caída de cornisa** | — | — | ✅ | — |
| **Explosivos** | — | — | ✅ | — |
| **ECT (Extended Column Test)** | ECTP <14 o ECTPV | ECTP 13-23 | ECTP >22 / ECTN <10 | ECTN >10 / ECTX |
| **Rutschblock** | RB1(wB,pR) / RB2(wB) | RB2(pR) / RB3(wB) | RB3(pR) / RB4-5(wB) | RB4-5(pR) / RB6-7 |

**Nota**: Las flechas en el diagrama EAWS indican que la existencia de evidencia hacia clases más inestables es imperativa (si hay liberación natural → very poor, no se puede clasificar como fair).

---

## Wet snow — Evidencia por clase de estabilidad

| Indicador | Very poor | Poor/Fair | Good |
|-----------|-----------|-----------|------|
| **Avalanchas naturales de nieve húmeda** | ✅ | — | — |
| **Avalanchas de nieve húmeda artificiales** | ✅ | ✅ | — |
| **Avance del frente de mojado** | ✅ → | ? | — |
| **Primera mojadura del manto** | ✅ → | ? | — |
| **Manto isotérmico por primera vez** | ✅ → | ? | — |
| **Capas débiles húmedas presentes** | ✅ → | ? | — |
| **Canales de flujo establecidos** | — | — | → ✅ |
| **Recongelamiento del manto** | — | — | → ✅ |
| **Contenido de agua líquida decreciente** | — | — | → ✅ |

**Regla**: Si no hay agua líquida en el manto → no hay avalanchas de nieve húmeda posibles.
Separación entre fair y poor es difícil para wet snow. Observaciones típicamente dan tendencia hacia good o very poor (bimodal).

---

## Glide snow — Evidencia por clase de estabilidad

| Indicador | Very poor | Poor/Fair | Good |
|-----------|-----------|-----------|------|
| **Avalanchas naturales de deslizamiento** | ✅ | — | — |
| **Agua líquida en interfaz nieve-suelo** | ✅ → | ? | — |
| **Aceleración de grietas de deslizamiento** | ✅ → | ? | — |
| **Carga por nieve nueva** | ✅ → | ? | — |

**Regla**: Si no hay agua líquida en la interfaz nieve-suelo → no hay glide-snow avalanches posibles.

---

## Comparación EAWS vs CMAH vs AAA

| EAWS Stability | AAA (2016) | CMAH Sensitivity | Human triggers | Explosive |
|----------------|------------|------------------|----------------|-----------|
| **Very poor** | Very poor | Touchy | Triggering almost certain | Any size |
| **Poor** | Poor | Reactive | Easy to trigger (ski cuts) | Single hand charge |
| **Fair** | Fair | Stubborn | Difficult to trigger | Large charges + air blasts |
| **Good** | Good–very good | Unreactive | No avalanches | No slab from very large cornice |

---

## Comparación frecuencia EAWS vs CMAH

| EAWS Frequency | CMAH Distribution | Descripción espacial CMAH |
|----------------|-------------------|--------------------------|
| **Many** | Widespread | En muchas ubicaciones y terrain features |
| **Some** | Specific | En features con características comunes |
| **A few** | Isolated | Spotty, en pocos terrain features |
| **None/nearly none** | — | No relevante para la evaluación |

---

## Aplicación en AndesAI: Mapeo de datos a clases EAWS

### Estabilidad (desde datos del sistema)

| Dato disponible | Indicador | Mapeo sugerido |
|-----------------|-----------|----------------|
| Factor de seguridad PINN < 1.0 | Manto muy inestable | → very poor |
| Factor de seguridad PINN 1.0-1.3 | Manto inestable | → poor |
| Factor de seguridad PINN 1.3-1.5 | Manto marginalmente estable | → fair |
| Factor de seguridad PINN > 1.5 | Manto estable | → good |
| Gradiente térmico > 10°C/m | Metamorfismo constructivo alto | Ajustar hacia poor/very poor |
| Nieve nueva > 30cm/24h | Problema new snow | Ajustar hacia poor/very poor |
| Viento > 40km/h + nieve nueva | Problema wind slab | Ajustar frecuencia +1 |

### Frecuencia (desde datos del sistema)

| Dato disponible | Indicador | Mapeo sugerido |
|-----------------|-----------|----------------|
| >20% de zonas de inicio en rango 30-60° | Muchas zonas potenciales | → many |
| 4-20% de zonas de inicio activas | Zonas específicas | → some |
| <4% de zonas de inicio | Pocas zonas | → a few |
| Sin zonas de inicio identificadas | Sin terreno avalanchoso | → none |
| Viento >40km/h | Transporte eólico activo | +1 clase frecuencia |
| Viento >70km/h | Transporte eólico intenso | +2 clases frecuencia |

### Tamaño (desde datos topográficos)

El paper confirma: estimar el **mayor tamaño que se puede esperar**.
La función `estimar_tamano_potencial(desnivel, area_ha, pendiente_max)` es la implementación correcta.
