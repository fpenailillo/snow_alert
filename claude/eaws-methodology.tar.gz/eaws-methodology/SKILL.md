---
name: eaws-methodology
description: Referencia completa de la metodología EAWS (European Avalanche Warning Services) para predicción de avalanchas. Usar siempre que se trabaje con la escala EAWS, la matriz de peligro, clasificación de niveles 1-5, factores de estabilidad/frecuencia/tamaño, workflow de evaluación, o cuando se necesiten definiciones formales para implementar o validar el sistema AndesAI/snow_alert. También activar cuando se mencione: EAWS matrix, snowpack stability, frequency distribution, avalanche size, danger level, Müller et al., Techel et al., CMAH, o cualquier concepto relacionado con la escala europea de peligro de avalanchas. Este skill es la fuente autoritativa de la metodología EAWS 2025 para el proyecto.
---

# EAWS Methodology — Referencia Técnica

Referencia completa de la metodología EAWS 2025 para el sistema AndesAI/snow_alert.
Basada en dos fuentes primarias:

1. **EAWS Matrix Definitions (2025)** — Documento oficial EAWS con definiciones, workflow y la matriz actualizada
2. **Müller, Techel & Mitterer (2025)** — Paper científico: desarrollo, encuesta a 76 forecasters, validación operacional

---

## Cuándo usar este skill

- Implementar o modificar `tool_clasificar_eaws.py` o `eaws_constantes.py`
- Escribir el marco teórico (§2.1 de la tesina)
- Justificar decisiones de diseño relacionadas con la escala EAWS
- Validar el sistema contra benchmarks internacionales
- Responder preguntas del comité sobre la matriz EAWS

---

## Los 3 factores que determinan el nivel de peligro

El nivel de peligro EAWS es función de **tres factores**:

### 1. Snowpack Stability (Estabilidad del manto nival)

Propiedad **local** del manto que describe la propensión de una ladera cubierta de nieve a producir una avalancha.

| Clase | Descripción | Desencadenante típico |
|-------|-------------|----------------------|
| **very poor** | Natural / muy fácil de desencadenar | Liberación natural, whumpfs largos, grietas |
| **poor** | Fácil de desencadenar | Un solo esquiador, carga baja |
| **fair** | Difícil de desencadenar | Explosivos, carga alta |
| **good** | Condiciones estables | Sin avalanchas |

Pregunta guía: *"¿Qué tan fácil es desencadenar una avalancha?"*

### 2. Frequency Distribution (Distribución de frecuencia)

Porcentaje de puntos para cada clase de estabilidad relativo a todos los puntos en terreno de avalanchas.

| Clase | Descripción | Evidencia |
|-------|-------------|-----------|
| **many** | Puntos abundantes | Fácil de encontrar evidencia de inestabilidad |
| **some** | Ni many ni few; en features comunes (crestas, couloirs) | Evidencia existe pero no siempre obvia |
| **a few** | Limitados en número, pero relevantes | Difícil de encontrar evidencia |
| **none/nearly none** | No existen o irrelevantes | — |

Pregunta guía: *"¿Qué tan frecuentes son los puntos donde pueden liberarse avalanchas?"*

### 3. Avalanche Size (Tamaño de avalancha)

Potencial destructivo. Se estima el **mayor tamaño esperado**.

| Tamaño | Nombre | Potencial destructivo |
|--------|--------|----------------------|
| 1 | Small | Improbable que entierre a una persona (salvo terrain traps) |
| 2 | Medium | Puede enterrar, herir o matar a una persona |
| 3 | Large | Puede destruir autos, dañar camiones, edificios pequeños |
| 4 | Very large | Puede destruir camiones, trenes, edificios grandes |
| 5 | Extremely large | Potencial catastrófico de devastación del paisaje |

Pregunta guía: *"¿Qué tan grandes pueden ser las avalanchas?"*

---

## La Matriz EAWS 2025

La matriz tiene **3 paneles** (uno por clase de estabilidad: very poor, poor, fair), conectados por flechas de izquierda a derecha. Cada panel cruza frecuencia (eje Y) × tamaño (eje X).

Para consultar la matriz completa con valores primarios y secundarios, leer: `references/eaws_matrix_2025.md`

### Lógica de uso

1. Comenzar por la estabilidad más desfavorable (very poor)
2. Si frecuencia es "none/nearly none" → pasar al siguiente panel (poor)
3. Repetir para poor, luego fair
4. Si estabilidad = good → nivel automáticamente 1 (Low)
5. Seleccionar el mayor tamaño esperado
6. La celda resultante indica D1 (primario) y opcionalmente D2 (secundario en paréntesis)

---

## Niveles de peligro EAWS (5 niveles)

| Nivel | Nombre | Descripción técnica resumida |
|-------|--------|------------------------------|
| 5 | Very High | Avalanchas naturales en muchas ubicaciones. Muy grandes a extremadamente grandes. |
| 4 | High | Fácil de desencadenar en muchas ubicaciones. Naturales en some/many. Grandes a muy grandes. |
| 3 | Considerable | Desencadenables en some [o many]. Naturales en nearly none a some. Medianas a grandes. |
| 2 | Moderate | Desencadenables en a few [o some]. Naturales nearly none o a few. Medianas. |
| 1 | Low | Nearly none donde se pueda desencadenar. Generalmente pequeñas, pueden ser medianas. |

---

## Workflow de 7 pasos para determinar el nivel

| Paso | Tarea | Pregunta guía |
|------|-------|---------------|
| 1 | Identificar problemas de avalancha presentes | ¿Qué tipos? (new snow, wind slab, persistent weak layer, wet snow, glide snow) |
| 2 | Determinar ubicaciones (elevación, aspecto) y hora | ¿Dónde y cuándo? |
| 3 | Evaluar clases de estabilidad del manto | ¿Qué tan fácil es desencadenar? |
| 4 | Evaluar frecuencia de esas clases | ¿Qué tan frecuentes son los puntos inestables? |
| 5 | Evaluar tamaño de avalancha | ¿Qué tan grandes pueden ser? |
| 6 | Consultar la matriz EAWS → obtener nivel | Cruce de estabilidad × frecuencia × tamaño |
| 7 | Elegir el nivel más alto entre todos los problemas | El peor escenario determina el nivel final |

Si no hay problemas de avalancha → nivel 1 (Low) automáticamente.

---

## Mapeo a la implementación AndesAI

| Concepto EAWS | Implementación snow_alert | Archivo |
|---------------|--------------------------|---------|
| Snowpack stability | `clase_estabilidad_eaws` (S1 Topográfico) | `tool_calcular_pinn.py` |
| Frequency | `frecuencia_estimada_eaws` (S1 + S3 Meteorológico) | `tool_analizar_dem.py` |
| Avalanche size | `estimar_tamano_potencial()` (desnivel, ha, pendiente) | `eaws_constantes.py` |
| Matrix lookup | `consultar_matriz_eaws(stability, frequency, size)` | `eaws_constantes.py` |
| Danger level | `nivel_eaws_24h/48h/72h` | `tool_clasificar_eaws.py` |
| Wind adjustment | >40km/h → +1 freq, >70km/h → +2 | `tool_clasificar_eaws.py` |
| 72h degradation | nivel_72h ≥ nivel_24h (conservador) | `tool_clasificar_eaws.py` |

---

## Referencias bibliográficas clave (formato IEEE)

```
[1] K. Müller, F. Techel, and C. Mitterer, "The EAWS matrix, a decision support tool to 
    determine the regional avalanche danger level (Part A): Conceptual development," 
    Nat. Hazards Earth Syst. Sci., vol. 25, pp. 4503–4525, 2025. 
    doi:10.5194/nhess-25-4503-2025

[2] EAWS Working Group Matrix and Scale, "Determination of the avalanche danger level 
    in regional avalanche forecasting," European Avalanche Warning Services, 
    updated May 2025, accepted June 2025.

[3] F. Techel, K. Müller, and J. Schweizer, "On the importance of snowpack stability, 
    the frequency distribution of snowpack stability and avalanche size in assessing 
    the avalanche danger level," The Cryosphere, vol. 14, pp. 3503–3521, 2020.

[4] G. Statham et al., "A conceptual model of avalanche hazard," Natural Hazards, 
    vol. 90, pp. 663–691, 2018.

[5] F. Techel, C. Mitterer, E. Ceaglio, and C. Coléou, "Spatial consistency and bias 
    in avalanche forecasts — a case study in the European Alps," Nat. Hazards Earth 
    Syst. Sci., vol. 18, pp. 2697–2716, 2018.
```

Para detalles de la matriz, el paper completo, o los apéndices → leer `references/eaws_matrix_2025.md`
